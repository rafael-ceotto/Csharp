﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace RafaelCeottoLab2
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        double calculatedInterest, loanAmount = 0, interestRate = 0.07, numberOfYears = 20;

        protected void Page_Load(object sender, EventArgs e)
        {
            lblResult.Text = "";
            if (!IsPostBack)
            {
                drpYears.Items.Add("Select Years ");
                drpYears.Items.Add("10");
                drpYears.Items.Add("15");
                drpYears.Items.Add("20");
            }
        }

        protected void btnClear_onClick(object sender, EventArgs e)
        {
            lblResult.Text = "";
            txtamount.Text = "";
            rdb5.Checked = false;
            rdb6.Checked = false;
            rdb7.Checked = false;
            drpYears.SelectedIndex = 0;
        }
              
        
        protected void btnCalculate_onClick(object sender, EventArgs e)
        {
            if (!(double.TryParse(txtamount.Text, out loanAmount)))
                loanAmount = 0;
            else if (rdb5.Checked)
                interestRate = 0.05;
            else if (rdb6.Checked)
                interestRate = 0.06;
            else if (rdb7.Checked)
                interestRate = 0.07;
            else
                interestRate = 0.07;
            if (!(double.TryParse(drpYears.SelectedValue, out numberOfYears)))
            {
                numberOfYears = 20;
            }
            
            
            calculatedInterest = loanAmount * interestRate * numberOfYears;

            String output = String.Format("Total interest for a loan of {0:C} at {1:0%} interest for {2} years is {3:c}",
            loanAmount, interestRate, numberOfYears, calculatedInterest);
            
            lblResult.Text = output;
        }
    }
}